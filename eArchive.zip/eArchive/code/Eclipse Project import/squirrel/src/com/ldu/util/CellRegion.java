package com.ldu.util;

/**
 * Created by lenovo on 2017/7/7.
 */
public class CellRegion {
    //记录合并单元格的每行记录起始和终点的行号
    int startrownum;
    int endrownum;
    String value;
}
