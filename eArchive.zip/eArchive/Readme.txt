The environment in which our project runs requires:
Windows 10 x64,
Jdk 1.8
Mysql 5.7
Tomcat7.0

To run the full project, please import   \code\Eclipse Project import\squirrel   into Eclipse and restore  \code\data\db_Sias Rental Platform.sql  into Mysql.

Before using, please use Eclipse to open the project and configure your mysql database login credentials in druid.username and druid.password in \squirrel\Java Resources\src\cnof\jdbc.properties (the default username is root, Empty password)



