﻿/**
 * Created by Guy，84651951.
 *  Tested by: Guy，84651951.
 *  Debugged by: Guy，84651951.
 */
package com.ldu.pojo;
/**
 * Commodity development joint query
 * @author lyq
 *
 */
import java.util.List;

public class CommentData extends Goods{
    private List<Comments> comments;
	public List<Comments> getComments() {
		return comments;
	}
	public void setComments(List<Comments> comments) {
		this.comments = comments;
	}
	
	
}