﻿package com.ldu.util;
/**
 * Created by Caden,84751102
 * Tested by Caden,84751102
 * Debugged by Caden,84751102
 */
import java.security.MessageDigest;

/**
 * MD5 Encryption class
 * @Description: Password encryption
 *
 */
public final class MD5 {

	/**
	 * Md5 encryption
	 * @param s
	 * @return
	 */
	public final static String md5(String s) {
        char hexDigits[] = { '0', '1', '2', '3', '4',
                             '5', '6', '7', '8', '9',
                             'A', 'B', 'C', 'D', 'E', 'F'};
        try {
            byte[] btInput = s.getBytes();
            MessageDigest mdInst = MessageDigest.getInstance("MD5");
            mdInst.update(btInput);
            byte[] md = mdInst.digest();
            int j = md.length;
            char str[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                str[k++] = hexDigits[byte0 >>> 4 & 0xf];
                str[k++] = hexDigits[byte0 & 0xf];
            }
            return new String(str);
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
	
	public static void main(String[] args) {
		System.out.println(MD5.md5("967042"));
	}
}
