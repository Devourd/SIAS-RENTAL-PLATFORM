﻿package com.ldu.util;

/**
 * Created by Caden,84751102
 * Tested by Caden,84751102
 * Debugged by Caden,84751102
 */
public class CellRegion {
    //Record the line number of the start and end of each row of the merged cell.
    int startrownum;
    int endrownum;
    String value;
}
